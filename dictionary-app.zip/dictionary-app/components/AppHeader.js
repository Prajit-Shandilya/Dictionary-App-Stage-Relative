
import * as React from 'react';
import {Text,View,StyleSheet} from 'react-native';

class AppHeader extends React.Component{
  render(){
    return(
    <View style={mystyle.textContainer}>
    <Text style={mystyle.text}>Dictionry App</Text>
    </View>
    );
  }

  
}

const mystyle = StyleSheet.create({
textContainer:{
  backgroundColor:'crimson',

},
text:{
  color:'white',
  fontSize:'45px',
  fontWeight:'bold',
  textAlign:'center',
 
}
});

export default AppHeader;
