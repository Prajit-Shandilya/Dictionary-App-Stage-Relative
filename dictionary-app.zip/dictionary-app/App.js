import * as React from 'react';
import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Image,
} from 'react-native';
import Constants from 'expo-constants';
import AppHeader from './components/AppHeader';

export default class App extends React.Component {
  constructor() {
    super();
    this.state = {
      text: '',
      word: '',
    };
  }
  getWord=(word)=>{
   var searchWord= word.toLowerCase();
   var url='https://rupinwhitehatjr.github.io/dictionary/'+searchWord+'.json'
   return fetch (url)
   .then((data)=>{ if(data.status===200)
{ return data.json()
} else { return null } })
.then((response)=>{var responseObj=response
if(responseObj){
  var wordData=responseObj.definations[0]
  var defination=wordData.description
  var lexicalCategory=wordData.wordtype
  this.setState({
    word:this.state.text,
    defination: defination,
    lexicalCategory:lexicalCategory

  })

}else {this.setState({
  word:this.state.text,
  defination: "Not Found"
})}
})
  }
  
  render() {
    return (
      <View>
        <AppHeader />
         <Image
          style={styles.icon}
          source={{
            uri:'https://www.nicepng.com/png/full/512-5126407_dictionary-clipart-png-clip-art.png',
              
          }}
        />
        <TextInput
          style={styles.inputBox}
          onChangeText={(text) => {
            this.setState({ text: text });
          }}
          value={this.state.text}
        /><TouchableOpacity style={styles.abc} onPress={this.getWord}>
        <Text style={styles.paragraph}>Search</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  /* container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },*/
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  inputBox: {
    marginTop: 50,
    width: '80%',
    alignSelf: 'center',
    height: 40,
    textAlign: 'center',
    borderWidth: 4,
    outline: 'none',
  },
  icon: {
    width: 150,
    height: 150,
    marginLeft: 95,
    marginTop:10,
  },
  abc:{
    justifyContent: 'center',
    alignSelf: 'center',
    borderWidth: 2,
    marginBottom:'',
    borderRadius: 100,
    marginTop: 30,
    width: 200,
    height: 60,
    
  }
});
